﻿using System;
namespace ca_Estacionamento
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
